#include "variant.h"

extern void **HardwareVectors;

volatile void* ___start = HardwareVectors[0];