#ifndef __UART_H_
#define __UART_H_

/* Peripheral Clock Speed = 40 MHz */
#define PERIPHERAL_CLK_SPEED 40000000
#define SET_BIT_HIGH 1
#define SET_BIT_LOW 0
#define SET_BYTE_HIGH 0xFF
#define SET_BYTE_LOW 0x00

typedef enum {
    UART_RX_COMPLETE,
    UART_TX_COMPLETE,
    UART_RX_CHAR,
    UART_TX_DATA_EMPTY
} uart_event_t;

typedef void (*callback_t)(unsigned char byte, uart_event_t event);

void SCI_Open(unsigned char channel, unsigned long baudrate);
void SCI_Close(unsigned char channel);
void SCI_SetCallback(unsigned char channel, callback_t callback);
void SCI_Read(unsigned char channel, unsigned char* const p_dest, unsigned long const bytes);
void SCI_Write(unsigned char channel, unsigned char* const p_src, unsigned long const bytes);

#endif