#ifndef __TPC_H_
#define __TPC_H_

typedef enum {
    TPC_GROUP_0 = 0x01,
    TPC_GROUP_1 = 0x02,
    TPC_GROUP_0_1 = 0x03,
    TPC_GROUP_2 = 0x04,
    TPC_GROUP_3 = 0x08,
    TPC_GROUP_2_3 = 0x0C
} tpc_group_t;

typedef enum {
    TPC_TP0 = 0x0001,
    TPC_TP1 = 0x0002,
    TPC_TP2 = 0x0004,
    TPC_TP3 = 0x0008,

    TPC_TP4 = 0x0010,
    TPC_TP5 = 0x0020,
    TPC_TP6 = 0x0040,
    TPC_TP7 = 0x0080,

    TPC_TP8 = 0x0100,
    TPC_TP9 = 0x0200,
    TPC_TP10 = 0x0400,
    TPC_TP11 = 0x0800,

    TPC_TP12 = 0x1000,
    TPC_TP13 = 0x2000,
    TPC_TP14 = 0x4000,
    TPC_TP15 = 0x8000
} tpc_pin_t;

typedef enum {
    TPC_MODE_NORMAL = 0,
    TPC_MODE_NONOVERLAPPING
} tpc_mode_t;

void TPC_Enable(unsigned short tpc);
void TPC_SetOutputTrigger(tpc_group_t group, unsigned char channel);
void TPC_SetOutputMode(tpc_group_t group, tpc_mode_t mode);
void TPC_SetNextData(tpc_group_t group, unsigned char data);

#endif