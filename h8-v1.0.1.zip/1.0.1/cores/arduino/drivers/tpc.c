#include "tpc.h"

#include "gpio.h"
#include "inthandler.h"
#include "intrinsic.h"
#include "iodefine.h"
#include "timer.h"

/***********************************************************************************
Function Name: TPC_Enable
Description:   Enable/Disable TPC output on a bit-by-bit basis
Parameters:    tpc: Bit 0 - Enable/Disable TPC output on TP0
                    Bit 1 - Enable/Disable TPC output on TP1
                    Bit 2 - Enable/Disable TPC output on TP2
                    Bit 3 - Enable/Disable TPC output on TP3
                    Bit 4 - Enable/Disable TPC output on TP4
                    Bit 5 - Enable/Disable TPC output on TP5
                    Bit 6 - Enable/Disable TPC output on TP6
                    Bit 7 - Enable/Disable TPC output on TP7
                    Bit 8 - Enable/Disable TPC output on TP8
                    Bit 9 - Enable/Disable TPC output on TP9
                    Bit 10 - Enable/Disable TPC output on TP10
                    Bit 11 - Enable/Disable TPC output on TP11
                    Bit 12 - Enable/Disable TPC output on TP12
                    Bit 13 - Enable/Disable TPC output on TP13
                    Bit 14 - Enable/Disable TPC output on TP14
                    Bit 15 - Enable/Disable TPC output on TP15
Return value:  none
***********************************************************************************/
void TPC_Enable(unsigned short tpc) {
    unsigned char b;
    b = tpc & 0xFF;
    if (b > 0) {
        IOPORT_PortDirectionSet(IO_PORT_0A, b);
        IOPORT_PortWrite(IO_PORT_0A, 0);
    }

    b = (tpc >> 8) & 0xFF;
    if (b > 0) {
        IOPORT_PortDirectionSet(IO_PORT_0B, b);
        IOPORT_PortWrite(IO_PORT_0B, 0);
    }

    TPC.NDERA.BYTE = (unsigned char)(tpc & 0xFF);
    TPC.NDERB.BYTE = (unsigned char)((tpc >> 8) & 0xFF);
}

/***********************************************************************************
Function Name: TPC_SetOutputTrigger
Description:   Select output trigger signals for a group (0 - 3)
Parameters:    group TPC_GROUP_0:   TP0-TP3
                     TPC_GROUP_1:   TP4-TP7
                     TPC_GROUP_0_1: TP0-TP7
                     TPC_GROUP_2:   TP8-TP11
                     TPC_GROUP_3:   TP12-TP15
                     TPC_GROUP_2_3: TP8-TP15
               channel: 0-3: ITU0-ITU3
Return value:  none
***********************************************************************************/
void TPC_SetOutputTrigger(tpc_group_t group, unsigned char channel) {
    if (channel > 3) return;

    switch (group) {
        case TPC_GROUP_0:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0x03) | (channel);
            break;
        case TPC_GROUP_1:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0x0C) | (channel << 2);
            break;
        case TPC_GROUP_0_1:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0x0F) | (channel << 2) | channel;
            break;
        case TPC_GROUP_2:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0x30) | (channel << 4);
            break;
        case TPC_GROUP_3:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0xC0) | (channel << 6);
            break;
        case TPC_GROUP_2_3:
            TPC.TPCR.BYTE = (TPC.TPCR.BYTE & ~0xF0) | (channel << 6) | (channel << 4);
            break;
    }
}

/***********************************************************************************
Function Name: TPC_SetOutputMode
Description:   Select output mode for a group (0 - 3)
Parameters:    group TPC_GROUP_0:   TP0-TP3
                     TPC_GROUP_1:   TP4-TP7
                     TPC_GROUP_0_1: TP0-TP7
                     TPC_GROUP_2:   TP8-TP11
                     TPC_GROUP_3:   TP12-TP15
                     TPC_GROUP_2_3: TP8-TP15
               mode: TPC_MODE_NORMAL - Normal TPC output
                     TPC_MODE_NONOVERLAPPING - Non-overlapping TPC output
Return value:  none
***********************************************************************************/
void TPC_SetOutputMode(tpc_group_t group, tpc_mode_t mode) {
    switch (group) {
        case TPC_GROUP_0:
        case TPC_GROUP_1:
        case TPC_GROUP_0_1:
        case TPC_GROUP_2:
        case TPC_GROUP_3:
        case TPC_GROUP_2_3:
            if (mode == TPC_MODE_NORMAL) {
                TPC.TPMR.BYTE &= ~group;
            } else {
                TPC.TPMR.BYTE |= group;
            }
            break;
    }
}

/***********************************************************************************
Function Name: TPC_SetNextData
Description:   Set next output data for a group (0 - 3)
Parameters:    group TPC_GROUP_0:   TP0-TP3
                     TPC_GROUP_1:   TP4-TP7
                     TPC_GROUP_0_1: TP0-TP7
                     TPC_GROUP_2:   TP8-TP11
                     TPC_GROUP_3:   TP12-TP15
                     TPC_GROUP_2_3: TP8-TP15
               data: data to set (4-bit for one group or 8-bit for 2 group)
Return value:  none
***********************************************************************************/
void TPC_SetNextData(tpc_group_t group, unsigned char data) {
    switch (group) {
        case TPC_GROUP_0:
            TPC.NDRA2.BYTE = data;
            break;
        case TPC_GROUP_1:
            TPC.NDRA1.BYTE = data << 4;
            break;
        case TPC_GROUP_0_1:
            TPC.NDRA1.BYTE = data;
            break;
        case TPC_GROUP_2:
            TPC.NDRB2.BYTE = data;
            break;
        case TPC_GROUP_3:
            TPC.NDRB1.BYTE = data << 4;
            break;
        case TPC_GROUP_2_3:
            TPC.NDRB1.BYTE = data;
            break;
    }
}