#include "dac.h"

#include "inthandler.h"
#include "iodefine.h"

/***********************************************************************************
Function Name: DAC_Start
Description:   Enables DAC and starts conversion of channel
Parameters:    channel - DAC channel
Return value:  none
***********************************************************************************/

void DAC_Start(dac_channel channel) {
    switch (channel) {
        case DAC_CHANNEL_0:
            DA.DACR.BIT.DAE = 0;
            DA.DACR.BIT.DAOE0 = 1;
            break;
        case DAC_CHANNEL_1:
            DA.DACR.BIT.DAE = 0;
            DA.DACR.BIT.DAOE1 = 1;
            break;
        case DAC_CHANNEL_ALL:
            DA.DACR.BIT.DAE = 1;
            DA.DACR.BIT.DAOE0 = 1;
            DA.DACR.BIT.DAOE1 = 1;
            break;
    }
}

/***********************************************************************************
Function Name: DAC_Stop
Description:   Disables DAC and stop conversion of channel
Parameters:    channel - DAC channel
Return value:  none
***********************************************************************************/

void DAC_Stop(dac_channel channel) {
    switch (channel) {
        case DAC_CHANNEL_0:
            DA.DACR.BIT.DAE = 0;
            DA.DACR.BIT.DAOE0 = 0;
            break;
        case DAC_CHANNEL_1:
            DA.DACR.BIT.DAE = 0;
            DA.DACR.BIT.DAOE1 = 0;
            break;
        case DAC_CHANNEL_ALL:
            DA.DACR.BIT.DAOE0 = 0;
            DA.DACR.BIT.DAOE1 = 0;
            break;
    }
}

/***********************************************************************************
Function Name: DAC_Standby
Description:   Enables or disables DAC output in software standby mode
Parameters:    value - 0: Disable !=0: Enable
Return value:  none
***********************************************************************************/

void DAC_Standby(unsigned char value) {
    DA.DASTCR.BIT.DASTE = (value != 0 ? 1 : 0);
}

/***********************************************************************************
Function Name: DAC_SetValue
Description:   Set the specified data holding register value for DAC channel
Parameters:    channel - DAC channel
*                 value - value to set
Return value:  none
***********************************************************************************/
void DAC_SetValue(dac_channel channel, unsigned char value) {
    switch (channel) {
        case DAC_CHANNEL_0:
            DA.DADR0 = value;
            break;
        case DAC_CHANNEL_1:
            DA.DADR1 = value;
            break;
        case DAC_CHANNEL_ALL:
            DA.DADR0 = value;
            DA.DADR1 = value;
            break;
    }
}
