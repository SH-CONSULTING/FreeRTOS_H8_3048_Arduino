#ifndef __GPIO_H_
#define __GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*interrupt_handle_t)(void);

typedef enum {
    IO_PORT_01,
    IO_PORT_02,
    IO_PORT_03,
    IO_PORT_04,
    IO_PORT_05,
    IO_PORT_06,
    IO_PORT_07,
    IO_PORT_08,
    IO_PORT_09,
    IO_PORT_0A,
    IO_PORT_0B,
} io_port_t;

typedef enum {
    IO_PORT_01_PIN_00,
    IO_PORT_01_PIN_01,
    IO_PORT_01_PIN_02,
    IO_PORT_01_PIN_03,
    IO_PORT_01_PIN_04,
    IO_PORT_01_PIN_05,
    IO_PORT_01_PIN_06,
    IO_PORT_01_PIN_07,

    IO_PORT_02_PIN_00,
    IO_PORT_02_PIN_01,
    IO_PORT_02_PIN_02,
    IO_PORT_02_PIN_03,
    IO_PORT_02_PIN_04,
    IO_PORT_02_PIN_05,
    IO_PORT_02_PIN_06,
    IO_PORT_02_PIN_07,

    IO_PORT_03_PIN_00,
    IO_PORT_03_PIN_01,
    IO_PORT_03_PIN_02,
    IO_PORT_03_PIN_03,
    IO_PORT_03_PIN_04,
    IO_PORT_03_PIN_05,
    IO_PORT_03_PIN_06,
    IO_PORT_03_PIN_07,

    IO_PORT_04_PIN_00,
    IO_PORT_04_PIN_01,
    IO_PORT_04_PIN_02,
    IO_PORT_04_PIN_03,
    IO_PORT_04_PIN_04,
    IO_PORT_04_PIN_05,
    IO_PORT_04_PIN_06,
    IO_PORT_04_PIN_07,

    IO_PORT_05_PIN_00,
    IO_PORT_05_PIN_01,
    IO_PORT_05_PIN_02,
    IO_PORT_05_PIN_03,
    IO_PORT_05_PIN_04,
    IO_PORT_05_PIN_05,
    IO_PORT_05_PIN_06,
    IO_PORT_05_PIN_07,

    IO_PORT_06_PIN_00,
    IO_PORT_06_PIN_01,
    IO_PORT_06_PIN_02,
    IO_PORT_06_PIN_03,
    IO_PORT_06_PIN_04,
    IO_PORT_06_PIN_05,
    IO_PORT_06_PIN_06,
    IO_PORT_06_PIN_07,

    IO_PORT_07_PIN_00,
    IO_PORT_07_PIN_01,
    IO_PORT_07_PIN_02,
    IO_PORT_07_PIN_03,
    IO_PORT_07_PIN_04,
    IO_PORT_07_PIN_05,
    IO_PORT_07_PIN_06,
    IO_PORT_07_PIN_07,

    IO_PORT_08_PIN_00,
    IO_PORT_08_PIN_01,
    IO_PORT_08_PIN_02,
    IO_PORT_08_PIN_03,
    IO_PORT_08_PIN_04,
    IO_PORT_08_PIN_05,
    IO_PORT_08_PIN_06,
    IO_PORT_08_PIN_07,

    IO_PORT_09_PIN_00,
    IO_PORT_09_PIN_01,
    IO_PORT_09_PIN_02,
    IO_PORT_09_PIN_03,
    IO_PORT_09_PIN_04,
    IO_PORT_09_PIN_05,
    IO_PORT_09_PIN_06,
    IO_PORT_09_PIN_07,

    IO_PORT_0A_PIN_00,
    IO_PORT_0A_PIN_01,
    IO_PORT_0A_PIN_02,
    IO_PORT_0A_PIN_03,
    IO_PORT_0A_PIN_04,
    IO_PORT_0A_PIN_05,
    IO_PORT_0A_PIN_06,
    IO_PORT_0A_PIN_07,

    IO_PORT_0B_PIN_00,
    IO_PORT_0B_PIN_01,
    IO_PORT_0B_PIN_02,
    IO_PORT_0B_PIN_03,
    IO_PORT_0B_PIN_04,
    IO_PORT_0B_PIN_05,
    IO_PORT_0B_PIN_06,
    IO_PORT_0B_PIN_07
} io_port_pin_t;

typedef enum {
    IO_LEVEL_LOW = 0,
    IO_LEVEL_HIGH
} io_level_t;

typedef enum {
    IO_DIRECTION_INPUT = 0,
    IO_DIRECTION_OUTPUT
} io_direction_t;

typedef enum {
    LOW_LEVEL = 0,
    FALLING_EDGE
} interrupt_mode_t;

void IOPORT_PortDirectionSet(io_port_t port, unsigned char direction);
void IOPORT_PinRead(io_port_pin_t pin, io_level_t *value);
void IOPORT_PinWrite(io_port_pin_t pin, io_level_t value);
void IOPORT_PortRead(io_port_t port, unsigned char *value);
void IOPORT_PortWrite(io_port_t port, unsigned char value);
void IOPORT_SetCallback(unsigned char irq_no, interrupt_handle_t callback, interrupt_mode_t mode);

#ifdef __cplusplus
}
#endif

#endif /* __GPIO_H_ */
