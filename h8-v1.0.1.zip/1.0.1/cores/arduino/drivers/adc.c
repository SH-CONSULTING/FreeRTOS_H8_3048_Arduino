#include "adc.h"

#include "inthandler.h"
#include "intrinsic.h"
#include "iodefine.h"

static adc_handle_t adc_handle;

volatile unsigned short _adc_value[8] = {0};
unsigned char adc_mode, adc_int, adc_channel;
unsigned short getValueOfChannel(unsigned char channel);
void refreshValueAllChannel();

void INT_ADI(void) {
    refreshValueAllChannel();

    if (adc_handle) adc_handle();

    /* Clear the AD End Flag by software */
    AD.ADCSR.BIT.ADF = 0;
}

/***********************************************************************************
Function Name: ADC_Init
Description:   Configuration of ADC channel
Parameters:    mode:        0: Single, 1: Scan
               interrupt:   0: Non_Int, 1: Int
               channel:     0 - 7
Return value:  none
***********************************************************************************/
void ADC_Init(unsigned char mode, unsigned char interrupt, unsigned char channel) {
    /* ADC conversion start flag. Set to 0 to stop ADC conversion */
    AD.ADCSR.BIT.ADST = 0;

    /* AD Control/Status Register for Unit 0 (ADCSR_0)
    b2:b1:b0 - CH2:CH1:CH0 - 000 (AN0 channel selected)
    b3       - CKS         - 0 (Clock Select. Selects the A/D conversion time.
                                Set to 0 to configure Conversion time = 266 states (maximum)
                                Set to 1 to configure Conversion time = 134 states (maximum))
    b4       - SCAN        - 0 (Scan mode. Selects single mode or scan mode)
    b5       - ADST        - 0 (A/D start. Starts or stops A/D conversion)
    b6       - ADIE        - 0 (A/D interrupt enable. Enables and disables A/D end interrupts)
    b7       - ADF         - 0 (AD End Flag. Indicates end of A/D conversion) */

    AD.ADCSR.BYTE = 0x00;

    if (mode)
        /* Scan mode */
        AD.ADCSR.BIT.SCAN = 1;

    if (interrupt)
        /* Enable A/D end interrupt */
        AD.ADCSR.BIT.ADIE = 1;

    /* Channel */
    AD.ADCSR.BYTE |= (unsigned char)channel;

    /* Enable external triggering of A/D conversion */
    AD.ADCR.BYTE = 0x80;

    adc_mode = mode;
    adc_int = interrupt;
    adc_channel = channel;
}

void ADC_Start() {
    if (AD.ADCSR.BIT.ADIE == 1) {
        /* Clear the AD End Flag by software */
        AD.ADCSR.BIT.ADF = 0;
    }

    /* ADC conversion start flag. Set to 1 to start ADC conversion */
    AD.ADCSR.BIT.ADST = 1;
}

void ADC_Start_IT() {
    /* Clear the AD End Flag by software */
    AD.ADCSR.BIT.ADF = 0;

    /* Enable A/D end interrupt */
    AD.ADCSR.BIT.ADIE = 1;

    /* ADC conversion start flag. Set to 1 to start ADC conversion */
    AD.ADCSR.BIT.ADST = 1;
}

void ADC_Stop() {
    /* Stop ADC conversion */
    AD.ADCSR.BIT.ADST = 0;
}

void ADC_Stop_IT() {
    /* Disable A/D end interrupt */
    AD.ADCSR.BIT.ADIE = 0;

    /* Stop ADC conversion */
    AD.ADCSR.BIT.ADST = 0;
}

int ADC_PollForConversion(unsigned long long timeout) {
#if 0
    portTickType tickstart = xTaskGetTickCount();

    while (AD.ADCSR.BIT.ADF == 0) {
        /* Wait till the AD conversion completes or timeout */

        if (xTaskGetTickCount() - tickstart > timeout) {
            return -1;
        }
    }
#else
    while (AD.ADCSR.BIT.ADF == 0) {
    }
#endif

    refreshValueAllChannel();

    /* Clear the AD End Flag by software */
    AD.ADCSR.BIT.ADF = 0;

    return 0;
}

void ADC_SetCallback(adc_handle_t callback) {
    adc_handle = callback;
}

void ADC_ScanCfg(unsigned char config) {
    /* AD Control/Status Register for Unit 0 (ADCSR_0)
    b2:b1:b0    - CH2:CH1:CH0   - 000 AN0
                                  001 AN0, AN1
                                  010 AN0 to AN2
                                  011 AN0 to AN3
                                  100 AN4
                                  101 AN4, AN5
                                  110 AN4 to AN6
                                  111 AN4 to AN7
    b3          - CKS   - 0 (Clock Select. Selects the A/D conversion time.
                             Set to 0 to configure Conversion time = 266 states (maximum)
                             Set to 1 to configure Conversion time = 134 states (maximum))
    b4          - SCAN  - 0 (Scan mode. Selects single mode or scan mode)
    b5          - ADST  - 0 (A/D start. Starts or stops A/D conversion)
    b6          - ADIE  - 0 (A/D interrupt enable. Enables and disables A/D end interrupts)
    b7          - ADF   - 0 (AD End Flag. Indicates end of A/D conversion) */

    AD.ADCSR.BIT.SCAN = 1;
    AD.ADCSR.BYTE |= config;
}

/***********************************************************************************
Function Name: getValueOfChannel
Description:   Read ADC value for a channel
Parameters:    unsigned short channel
Return value:  Value
***********************************************************************************/
unsigned short getValueOfChannel(unsigned char channel) {
    /* Initialize the variable "usADC_Result" used to store the ADC result */
    unsigned short usADC_Result = 0;

    /* Save the ADC result */
    switch (channel) {
        case 0:
        case 4:
            usADC_Result = (unsigned short)AD.ADDRA;
            break;
        case 1:
        case 5:
            usADC_Result = (unsigned short)AD.ADDRB;
            break;
        case 2:
        case 6:
            usADC_Result = (unsigned short)AD.ADDRC;
            break;
        case 3:
        case 7:
            usADC_Result = (unsigned short)AD.ADDRD;
            break;
    }

    /*    Only 10 most significant bits of the result are valid.
    Shift the result by six bits to make it convenient to read */
    usADC_Result >>= 6;

    /* Save the ADC result */
    return usADC_Result;
}

void refreshValueAllChannel() {
    /*
    b2:b1:b0    - CH2:CH1:CH0   - 000 AN0
                                  001 AN0, AN1
                                  010 AN0 to AN2
                                  011 AN0 to AN3
                                  100 AN4
                                  101 AN4, AN5
                                  110 AN4 to AN6
                                  111 AN4 to AN7
    */
    unsigned char channel, end_channel;

    // Clear
    for (channel = 0; channel <= 7; channel++) {
        _adc_value[channel] = 0;
    }

    end_channel = ADC_Channel();
    channel = (ADC_Mode() ? (channel >= 4 ? 4 : 0) : end_channel);

    for (; channel <= end_channel; channel++) {
        _adc_value[channel] = getValueOfChannel(channel);
    }
}

unsigned short ADC_GetValue(unsigned short channel) {
    return _adc_value[channel];
}

unsigned char ADC_Mode() {
    return adc_mode;
}

unsigned char ADC_Interrupt() {
    return adc_int;
}

unsigned char ADC_Channel() {
    return adc_channel;
}
