#include "timer.h"

#include "inthandler.h"
#include "intrinsic.h"
#include "iodefine.h"

volatile itu_ctrl_t _itu_ctrl[5] = {0};

/***********************************************************************************
Function Name:  INT_IMIA0
Description:    Compare match/input capture A0 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIA0(void) {
    /* Clear timer interrupt flag */
    ITU0.TSR.BIT.IMFA = 0;

    if (_itu_ctrl[0].callback) {
        _itu_ctrl[0].callback(TIMER_EVENT_CAPTURE_A);
    }
}

/***********************************************************************************
Function Name:  INT_IMIB0
Description:    Compare match/input capture B0 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIB0(void) {
    /* Clear timer interrupt flag */
    ITU0.TSR.BIT.IMFB = 0;

    if (_itu_ctrl[0].callback) {
        _itu_ctrl[0].callback(TIMER_EVENT_CAPTURE_B);
    }
}

/***********************************************************************************
Function Name:  INT_OVI0
Description:    ITU0 Overflow interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_OVI0(void) {
    /* Clear timer interrupt flag */
    ITU0.TSR.BIT.OVF = 0;

    if (_itu_ctrl[0].callback) {
        _itu_ctrl[0].callback(TIMER_EVENT_CYCLE_END);
    }
}

/***********************************************************************************
Function Name:  INT_IMIA1
Description:    Compare match/input capture A1 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIA1(void) {
    /* Clear timer interrupt flag */
    ITU1.TSR.BIT.IMFA = 0;

    if (_itu_ctrl[1].callback) {
        _itu_ctrl[1].callback(TIMER_EVENT_CAPTURE_A);
    }
}

/***********************************************************************************
Function Name:  INT_IMIB1
Description:    Compare match/input capture B1 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIB1(void) {
    /* Clear timer interrupt flag */
    ITU1.TSR.BIT.IMFB = 0;

    if (_itu_ctrl[1].callback) {
        _itu_ctrl[1].callback(TIMER_EVENT_CAPTURE_B);
    }
}

/***********************************************************************************
Function Name:  INT_OVI1
Description:    ITU1 Overflow interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_OVI1(void) {
    /* Clear timer interrupt flag */
    ITU1.TSR.BIT.OVF = 0;

    if (_itu_ctrl[1].callback) {
        _itu_ctrl[1].callback(TIMER_EVENT_CYCLE_END);
    }
}

/***********************************************************************************
Function Name:  INT_IMIA2
Description:    Compare match/input capture A2 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIA2(void) {
    /* Clear timer interrupt flag */
    ITU2.TSR.BIT.IMFA = 0;

    if (_itu_ctrl[2].callback) {
        _itu_ctrl[2].callback(TIMER_EVENT_CAPTURE_A);
    }
}

/***********************************************************************************
Function Name:  INT_IMIB2
Description:    Compare match/input capture B2 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIB2(void) {
    /* Clear timer interrupt flag */
    ITU2.TSR.BIT.IMFB = 0;

    if (_itu_ctrl[2].callback) {
        _itu_ctrl[2].callback(TIMER_EVENT_CAPTURE_B);
    }
}

/***********************************************************************************
Function Name:  INT_OVI2
Description:    ITU2 Overflow interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_OVI2(void) {
    /* Clear timer interrupt flag */
    ITU2.TSR.BIT.OVF = 0;

    if (_itu_ctrl[2].callback) {
        _itu_ctrl[2].callback(TIMER_EVENT_CYCLE_END);
    }
}

/***********************************************************************************
Function Name:  INT_IMIA3
Description:    Compare match/input capture A3 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIA3(void) {
    /* Clear timer interrupt flag */
    ITU3.TSR.BIT.IMFA = 0;

    if (_itu_ctrl[3].callback) {
        _itu_ctrl[3].callback(TIMER_EVENT_CAPTURE_A);
    }
}

/***********************************************************************************
Function Name:  INT_IMIB3
Description:    Compare match/input capture B3 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIB3(void) {
    /* Clear timer interrupt flag */
    ITU3.TSR.BIT.IMFB = 0;

    if (_itu_ctrl[3].callback) {
        _itu_ctrl[3].callback(TIMER_EVENT_CAPTURE_B);
    }
}

/***********************************************************************************
Function Name:  INT_OVI3
Description:    ITU3 Overflow interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_OVI3(void) {
    /* Clear timer interrupt flag */
    ITU3.TSR.BIT.OVF = 0;

    if (_itu_ctrl[3].callback) {
        _itu_ctrl[3].callback(TIMER_EVENT_CYCLE_END);
    }
}

/***********************************************************************************
Function Name:  INT_IMIA4
Description:    Compare match/input capture A4 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIA4(void) {
    /* Clear timer interrupt flag */
    ITU4.TSR.BIT.IMFA = 0;

    if (_itu_ctrl[4].callback) {
        _itu_ctrl[4].callback(TIMER_EVENT_CAPTURE_A);
    }
}

/***********************************************************************************
Function Name:  INT_IMIB4
Description:    Compare match/input capture B4 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IMIB4(void) {
    /* Clear timer interrupt flag */
    ITU4.TSR.BIT.IMFB = 0;

    if (_itu_ctrl[4].callback) {
        _itu_ctrl[4].callback(TIMER_EVENT_CAPTURE_B);
    }
}

/***********************************************************************************
Function Name:  INT_OVI4
Description:    ITU4 Overflow interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_OVI4(void) {
    /* Clear timer interrupt flag */
    ITU0.TSR.BIT.OVF = 0;

    if (_itu_ctrl[4].callback) {
        _itu_ctrl[4].callback(TIMER_EVENT_CYCLE_END);
    }
}

/***********************************************************************************
Function Name:  ITU_Open
Description:    Initialize ITU.
Parameters:     channel: 0-4
                config: configuration parameters
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_IN_USE: Timer is in use
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_Open(unsigned char channel, itu_config_t config) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (!_itu_ctrl[channel].open) {
        _itu_ctrl[channel].open = 1;
        _itu_ctrl[channel].callback = 0;
        _itu_ctrl[channel].config = config;

        switch (channel) {
            case 0:
                _itu_ctrl[channel].p_reg = (unsigned long)&ITU0;
                break;
            case 1:
                _itu_ctrl[channel].p_reg = (unsigned long)&ITU1;
                break;
            case 2:
                _itu_ctrl[channel].p_reg = (unsigned long)&ITU2;
                break;
            case 3:
                _itu_ctrl[channel].p_reg = (unsigned long)&ITU3;
                break;
            case 4:
                _itu_ctrl[channel].p_reg = (unsigned long)&ITU4;
                break;
        }

        /* TODO: Select high priority level for ITU. Needed? */
        /*
        if (channel<=2) {
            INTC.IPRA.BYTE = 1<<channel;
        } else {
            INTC.IPRB.BYTE = 1<< (10-channel);
        }
        */

        /* Set Timer Control Register, (TCR) */
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TCR.BIT.TPSC = config.timer_source;
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TCR.BIT.CKEG = config.clock_edge;
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TCR.BIT.CCLR = config.counter_clear;

        return TIMER_SUCCESS;
    } else {
        return TIMER_IN_USE;
    }
}

/***********************************************************************************
Function Name:  ITU_Close
Description:    Close ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_Close(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        _itu_ctrl[channel].open = 0;
    }
    return TIMER_SUCCESS;
}

/***********************************************************************************
Function Name:  ITU_Start
Description:    Start ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_Start(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        ITU.TSTR.BYTE |= (1 << channel);
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_Stop
Description:    Stop ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_Stop(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        ITU.TSTR.BYTE &= ~(1 << channel);
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_Reset
Description:    Reset ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_Reset(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        ITU.TSTR.BYTE &= ~(1 << channel);

        // Reset TCNT
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TCNT = 0;

        ITU.TSTR.BYTE |= (1 << channel);
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_EnableIRQ
Description:    Enable IRQ for ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_EnableIRQ(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        set_imask_ccr(1);

        // Enable interrupt IMIEA, IMIEB, OVIE
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TIER.BYTE = 0xF8 | 0x07;

        /* Clear timer interrupt flag */
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TSR.BIT.IMFA = 0;

        set_imask_ccr(0);
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_DisableIRQ
Description:    Disable IRQ for ITU.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_DisableIRQ(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;

    if (_itu_ctrl[channel].open) {
        set_imask_ccr(1);

        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TIER.BYTE = 0xF8;

        set_imask_ccr(0);
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_SetCallback
Description:    Set callback for ITU.
Parameters:     channel: 0-4
                callback: callback function
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_SetCallback(unsigned char channel, timer_handle_t callback) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open) {
        _itu_ctrl[channel].callback = callback;

        if (callback) {
            ITU_EnableIRQ(channel);
        } else {
            ITU_DisableIRQ(channel);
        }
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_SetGRA
Description:    Set GRA register for specific timer channel.
Parameters:     channel: 0-4
                value: value to set
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_SetGRA(unsigned char channel, unsigned short value) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open) {
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).GRA = value;
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_SetGRB
Description:    Set GRB register for specific timer channel.
Parameters:     channel: 0-4
                value: value to set
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_SetGRB(unsigned char channel, unsigned short value) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open) {
        (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).GRB = value;
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  ITU_IOControl
Description:    Control IO for ITU.
Parameters:     channel: 0-4
                pin:
                    + TIMER_IO_PIN_TIOCA: TIOCA pin
                    + TIMER_IO_PIN_TIOCB: TIOCB pin
                    + TIMER_IO_PIN_TIOCA_AND_TIOCB: both TIOCA and TIOCB pins.
                control:
                    + TIMER_IO_CTRL_NO_OUTPUT: No output at compare match
                    + TIMER_IO_CTRL_OUTPUT_LOW: 0 output at compare match
                    + TIMER_IO_CTRL_OUTPUT_HIGH: 1 output at compare match
                    + TIMER_IO_CTRL_OUTPUT_TOGGLE: Output toggles at compare match (Output High in CH2)
                    + TIMER_IO_CTRL_INPUT_RISING_EDGE: captures rising edge of input
                    + TIMER_IO_CTRL_INPUT_FALLING_EDGE: captures falling edge of input
                    + TIMER_IO_CTRL_INPUT_BOTH_EDGE: captures both edges of input
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t ITU_IOControl(unsigned char channel, timer_io_pin_t pin, timer_io_control_t control) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open) {
        if (TIMER_IO_PIN_TIOCA != pin) {
            // TIOB or TIOA_AND_TIOB
            (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TIOR.BYTE = (ITU0.TIOR.BYTE & (0x8F)) | (control << 4);
        }

        if (TIMER_IO_PIN_TIOCB != pin) {
            // TIOA or TIOA_AND_TIOB
            (*(volatile struct st_itu0*)(_itu_ctrl[channel].p_reg)).TIOR.BYTE = (ITU0.TIOR.BYTE & (0xF8)) | control;
        }
        return TIMER_SUCCESS;
    }
    return TIMER_NOT_OPEN;
}

/***********************************************************************************
Function Name:  GPT_Open
Description:    Initialize ITU in periodic mode (Interval Timer).
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_IN_USE: Timer is in use
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_Open(unsigned char channel) {
    itu_config_t config;
    config.mode = TIMER_MODE_PERIODIC;
    config.timer_source = TIMER_SOURCE_DIV_8;
    config.counter_clear = CCLR_CLEAR_ON_GRA_COMPARE_MATCH;
    return ITU_Open(channel, config);
}

/***********************************************************************************
Function Name:  GPT_Close
Description:    Close GPT.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_IN_USE: Timer is in use in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_Close(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_IN_USE;
    }
    return ITU_Close(channel);
}

/***********************************************************************************
Function Name:  GPT_Start
Description:    Start GPT.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_Start(unsigned char channel) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_NOT_OPEN;
    }
    return ITU_Start(channel);
}

/***********************************************************************************
Function Name:  GPT_Stop
Description:    Stop GPT.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_Stop(unsigned char channel) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_NOT_OPEN;
    }
    return ITU_Stop(channel);
}

/***********************************************************************************
Function Name:  GPT_SetCallback
Description:    Set callback for GPT channel.
Parameters:     channel: 0-4
                callback: callback function
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_SetCallback(unsigned char channel, timer_handle_t callback) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_NOT_OPEN;
    }
    return ITU_SetCallback(channel, callback);
}

/***********************************************************************************
Function Name:  GPT_SetInterval
Description:    Set interval for GPT in microseconds.
Parameters:     channel: 0-4
                interval: interval in microseconds (interval <= 13107us)
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_SetInterval(unsigned char channel, unsigned short const interval) {
    timer_error_code_t ret;
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (interval > 13107) return TIMER_INVALID_ARGUMENT;
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_NOT_OPEN;
    }

    ret = ITU_SetGRA(channel, interval * 5);
    if (ret != TIMER_SUCCESS) return ret;

    /* Select Normal mode for channel */
    ITU.TMDR.BYTE &= ~(1 << channel);

    return TIMER_SUCCESS;
}

/***********************************************************************************
Function Name:  GPT_SetOutput
Description:    Set output (at TIOCA pin) for GPT channel.
Parameters:     channel: 0-4
                control:
                    + TIMER_IO_CTRL_NO_OUTPUT: No output at compare match
                    + TIMER_IO_CTRL_OUTPUT_LOW: 0 output at compare match
                    + TIMER_IO_CTRL_OUTPUT_HIGH: 1 output at compare match
                    + TIMER_IO_CTRL_OUTPUT_TOGGLE: Output toggles at compare match (Output High in CH2)
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t GPT_SetOutput(unsigned char channel, timer_io_control_t control) {
    if (control > TIMER_IO_CTRL_OUTPUT_TOGGLE) return TIMER_INVALID_ARGUMENT;
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PERIODIC) {
        return TIMER_NOT_OPEN;
    }

    return ITU_IOControl(channel, TIMER_IO_PIN_TIOCA, control);
}