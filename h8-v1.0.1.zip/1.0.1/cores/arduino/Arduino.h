#ifndef Arduino_h
#define Arduino_h

#ifdef __cplusplus
extern "C"{
#endif

#include "gpio.h"
#include "uart.h"
#include "pwm.h"
#include "timer.h"
#include "tpc.h"
#include "adc.h"
#include "dac.h"

#ifdef __cplusplus
} // extern "C"
#endif

/* sketch */
extern void setup(void);
extern void loop(void);

#endif // Arduino_h