/*********************************************************************
* DISCLAIMER:                                                        *
* The software supplied by Renesas Technology America Inc. is        *
* intended and supplied for use on Renesas Technology products.      *
* This software is owned by Renesas Technology America, Inc. or      *
* Renesas Technology Corporation and is protected under applicable   *
* copyright laws. All rights are reserved.                           *
*                                                                    * 
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, *
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED         *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE *
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND       *
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT      *
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS          *
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL, *
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR        *
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE *
* USE OR APPLICATION OF THIS SOFTWARE.                               *
*********************************************************************/
/***********************************************************************/
/*                                                                     */
/*  FILE        :FreeRTOSPort.h                                        */
/*  DATE        :April 28, 2008                                        */
/*  DESCRIPTION :Platform specific macros for FreeRTOS                 */
/*  CPU TYPE    :H8S/2378R                                             */
/*                                                                     */
/***********************************************************************/
/************************************************************************
Revision History
DD.MM.YYYY OSO-UID Description
*
************************************************************************/

#ifndef FREERTOS_PORT_H
#define FREERTOS_PORT_H

#include "../iodefine.h"
//#include "timer.h"

// Platform specific macros provided by users
#define  TRAP_VECT          8
#define  TMR_VECT           72

#define  TMR_INT_PRIORITY() INTC.IPRA.BIT._ITU0 = configKERNEL_INTERRUPT_PRIORITY;
#define  CLR_TMR_INT()      ITU0.TSR.BIT.IMFA = 0;
#define  CONFIG_TMR()       ITU.TSTR.BIT.STR0 = 0x0;\
                            ITU.TMDR.BYTE = 0xc0;\
                            ITU0.TCR.BYTE = 0x23;\
                            set_ccr((unsigned char)1);\
                            ITU0.TIER.BYTE = 0x43;\
                            ITU0.GRA = 0x7FFF;\
                            ITU0.GRB = 0x3FFF;\
                            set_ccr((unsigned char)0);\
                            //MSTPCR.BIT._TMR = 0; TMR0.TCR.BIT.CMIEA = 1; TMR0.TCR.BIT.CCLR = 1; \
                            /* One of three div. factors must be chosen dep. on cpu clock and tick rate \
                            /*TMR0.TCR.BIT.CKS = (unsigned char)1;                                      \
                            TMR0.TCORA = (unsigned short) (configCPU_CLOCK_HZ/configTICK_RATE_HZ/8);    \
                            /*TMR0.TCR.BIT.CKS = (unsigned char)2;                                      \
                            TMR0.TCORA = (unsigned short) (configCPU_CLOCK_HZ/configTICK_RATE_HZ/64);*/ \
                            // TMR0.TCR.BIT.CKS = (unsigned char)3;                                        \
                            // TMR0.TCORA = (unsigned short)(configCPU_CLOCK_HZ/configTICK_RATE_HZ/SYSTIMER_DIV_FACTOR_8192);  \
                            // if ((TMR0.TCORA == 0)) TMR0.TCORA = 255;              
#endif /* FREERTOS_PORT_H */