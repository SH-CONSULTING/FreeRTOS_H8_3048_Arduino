/***********************************************************************/
/*                                                                     */
/*  FILE        :main.cpp                                              */
/*  DATE        :Tue, Sep 20, 2022                                     */
/*  DESCRIPTION :Main Program                                          */
/*  CPU TYPE    :H8/3048                                               */
/*                                                                     */
/*                                                                     */
/***********************************************************************/

#include <Arduino.h>

#ifdef CPPAPP
// Initialize global constructors
extern "C" void __main() {
    static int initialized;
    if (!initialized) {
        typedef void (*pfunc)();
        extern pfunc __ctors[];
        extern pfunc __ctors_end[];
        pfunc *p;

        initialized = 1;
        for (p = __ctors_end; p > __ctors;)
            (*--p)();
    }
}
#endif

int main(void) {
    setup();

    for (;;) {
        loop();
    }

    return 0;
}
