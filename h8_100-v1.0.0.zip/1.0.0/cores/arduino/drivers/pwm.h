#ifndef __PWM_H_
#define __PWM_H_

#include "timer.h"

timer_error_code_t PWM_Open(unsigned char channel);
timer_error_code_t PWM_Close(unsigned char channel);
timer_error_code_t PWM_Start(unsigned char channel);
timer_error_code_t PWM_Stop(unsigned char channel);
timer_error_code_t PWM_SetCallback(unsigned char channel, timer_handle_t callback);
timer_error_code_t PWM_SetPeriodAndDuty(unsigned char channel, unsigned short duty_cycle_us, unsigned short period_us);

#endif