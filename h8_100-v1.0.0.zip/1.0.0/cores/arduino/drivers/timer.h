#ifndef __TIMER_H_
#define __TIMER_H_

#define ITU_CHANNEL_MAX 5
#define TIMER_CONVERT_VALUE_TO_MS(x) x

typedef enum {
    TIMER_SUCCESS,
    TIMER_IN_USE,
    TIMER_INVALID_ARGUMENT,
    TIMER_NOT_OPEN
} timer_error_code_t;

typedef enum {
    TIMER_MODE_PERIODIC,
    TIMER_MODE_PWM
} timer_mode_t;

typedef enum {
    TIMER_IO_PIN_TIOCA,
    TIMER_IO_PIN_TIOCB,
    TIMER_IO_PIN_TIOCA_AND_TIOCB
} timer_io_pin_t;

typedef enum {
    TIMER_IO_CTRL_NO_OUTPUT = 0,
    TIMER_IO_CTRL_OUTPUT_LOW,
    TIMER_IO_CTRL_OUTPUT_HIGH,
    TIMER_IO_CTRL_OUTPUT_TOGGLE, /* Output High in CH2 */
    TIMER_IO_CTRL_INPUT_RISING_EDGE,
    TIMER_IO_CTRL_INPUT_FALLING_EDGE,
    TIMER_IO_CTRL_INPUT_BOTH_EDGE,
} timer_io_control_t;

typedef enum {
    TIMER_EVENT_CYCLE_END,
    TIMER_EVENT_CAPTURE_A,
    TIMER_EVENT_CAPTURE_B
} timer_event_t;

typedef enum {
    CCLR_NOT_CLEARED = 0,
    CCLR_CLEAR_ON_GRA_COMPARE_MATCH,
    CCLR_CLEAR_ON_GRB_COMPARE_MATCH,
    CCLR_SYNC_CLEAR
} counter_clear_t;

typedef enum {
    CKEG_RISING = 0,
    CKEG_FALLING,
    CKEG_BOTH
} clock_edge_t;

typedef enum {
    TIMER_SOURCE_DIV_1 = 0,  ///< Timer clock source divided by 1
    TIMER_SOURCE_DIV_2 = 1,  ///< Timer clock source divided by 2
    TIMER_SOURCE_DIV_4 = 2,  ///< Timer clock source divided by 4
    TIMER_SOURCE_DIV_8 = 3,  ///< Timer clock source divided by 8
    TIMER_SOURCE_TCLKA = 4,  ///< External clock A: TCLKA input
    TIMER_SOURCE_TCLKB = 5,  ///< External clock B: TCLKB input
    TIMER_SOURCE_TCLKC = 6,  ///< External clock C: TCLKC input
    TIMER_SOURCE_TCLKD = 7,  ///< External clock D: TCLKD input
} timer_source_t;

typedef struct {
    timer_mode_t mode;
    timer_source_t timer_source;
    clock_edge_t clock_edge;
    counter_clear_t counter_clear;
} itu_config_t;

typedef void (*timer_handle_t)(timer_event_t event);

typedef struct {
    unsigned char open;
    itu_config_t config;
    timer_handle_t callback;
    unsigned long p_reg;
} itu_ctrl_t;

timer_error_code_t ITU_Open(unsigned char channel, itu_config_t config);
timer_error_code_t ITU_Close(unsigned char channel);
timer_error_code_t ITU_Start(unsigned char channel);
timer_error_code_t ITU_Stop(unsigned char channel);
timer_error_code_t ITU_Reset(unsigned char channel);
timer_error_code_t ITU_EnableIRQ(unsigned char channel);
timer_error_code_t ITU_DisableIRQ(unsigned char channel);
timer_error_code_t ITU_SetCallback(unsigned char channel, timer_handle_t callback);
timer_error_code_t ITU_SetGRA(unsigned char channel, unsigned short value);
timer_error_code_t ITU_SetGRB(unsigned char channel, unsigned short value);
timer_error_code_t ITU_IOControl(unsigned char channel, timer_io_pin_t pin, timer_io_control_t control);

timer_error_code_t GPT_Open(unsigned char channel);
timer_error_code_t GPT_Close(unsigned char channel);
timer_error_code_t GPT_Start(unsigned char channel);
timer_error_code_t GPT_Stop(unsigned char channel);
timer_error_code_t GPT_SetCallback(unsigned char channel, timer_handle_t callback);
timer_error_code_t GPT_SetInterval(unsigned char channel, unsigned short const interval);
timer_error_code_t GPT_SetOutput(unsigned char channel, timer_io_control_t control);

#endif