#include "uart.h"

#include "inthandler.h"
#include "intrinsic.h"
#include "iodefine.h"

typedef struct {
    unsigned char const* p_tx_src;
    unsigned long tx_src_bytes;

    unsigned char* p_rx_dest;
    unsigned long rx_dest_bytes;

    callback_t callback;
} sci_ctrl_t;

volatile sci_ctrl_t _sci_ctrl[2];

/***********************************************************************************
Function Name:  INT_RXI0
Description:    SCI0 receive interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_RXI0(void) {
    /* Clear the RDRF flag */
    SCI0.SSR.BIT.RDRF = SET_BIT_LOW;

    /* Read the received data */
    unsigned char rx_data = SCI0.RDR;

    if (_sci_ctrl[0].rx_dest_bytes > 0) {
        *(_sci_ctrl[0].p_rx_dest) = rx_data;
        _sci_ctrl[0].p_rx_dest++;
        _sci_ctrl[0].rx_dest_bytes--;
        if (_sci_ctrl[0].rx_dest_bytes == 0) {
            if (_sci_ctrl[0].callback) {
                _sci_ctrl[0].callback(0, UART_RX_COMPLETE);
            }
        }
    } else {
        if (_sci_ctrl[0].callback) {
            _sci_ctrl[0].callback(rx_data, UART_RX_CHAR);
        }
    }
}

/***********************************************************************************
Function Name:  INT_TEI0
Description:    SCI0 transmit end interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_TEI0(void) {
    SCI0.SCR.BIT.TEIE = 0;

    if (_sci_ctrl[0].callback) {
        _sci_ctrl[0].callback(0, UART_TX_COMPLETE);
    }
}

/***********************************************************************************
Function Name:  INT_TXI0
Description:    SCI0 transmit interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_TXI0(void) {
    if (_sci_ctrl[0].tx_src_bytes > 0) {
        SCI0.TDR = _sci_ctrl[0].p_tx_src[0];
        SCI0.SSR.BIT.TDRE = SET_BIT_LOW;

        _sci_ctrl[0].p_tx_src++;
        _sci_ctrl[0].tx_src_bytes--;
    }

    if (_sci_ctrl[0].tx_src_bytes == 0) {
        // Disable Transmit interrupt
        SCI0.SCR.BIT.TIE = 0;

        // Enable Transmit end interrupt
        SCI0.SCR.BIT.TEIE = 1;

        //_sci_ctrl[0].p_tx_src = 0;

        if (_sci_ctrl[0].callback) {
            _sci_ctrl[0].callback(0, UART_TX_DATA_EMPTY);
        }
    }
}

/***********************************************************************************
Function Name:  INT_RXI1
Description:    SCI1 receive interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_RXI1(void) {
    /* Clear the RDRF flag */
    SCI1.SSR.BIT.RDRF = SET_BIT_LOW;

    /* Read the received data */
    unsigned char rx_data = SCI1.RDR;

    if (_sci_ctrl[1].rx_dest_bytes > 0) {
        *(_sci_ctrl[1].p_rx_dest) = rx_data;
        _sci_ctrl[1].p_rx_dest++;
        _sci_ctrl[1].rx_dest_bytes--;
        if (_sci_ctrl[1].rx_dest_bytes == 0) {
            if (_sci_ctrl[1].callback) {
                _sci_ctrl[1].callback(0, UART_RX_COMPLETE);
            }
        }
    } else {
        if (_sci_ctrl[1].callback) {
            _sci_ctrl[1].callback(rx_data, UART_RX_CHAR);
        }
    }
}

/***********************************************************************************
Function Name:  INT_TEI1
Description:    SCI1 transmit end interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_TEI1(void) {
    SCI1.SCR.BIT.TEIE = 0;

    if (_sci_ctrl[1].callback) {
        _sci_ctrl[1].callback(0, UART_TX_COMPLETE);
    }
}

/***********************************************************************************
Function Name:  INT_TXI1
Description:    SCI1 transmit interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_TXI1(void) {
    if (_sci_ctrl[1].tx_src_bytes > 0) {
        SCI1.TDR = _sci_ctrl[1].p_tx_src[0];
        SCI1.SSR.BIT.TDRE = SET_BIT_LOW;

        _sci_ctrl[1].p_tx_src++;
        _sci_ctrl[1].tx_src_bytes--;
    }

    if (_sci_ctrl[1].tx_src_bytes == 0) {
        // Disable Transmit interrupt
        SCI1.SCR.BIT.TIE = 0;

        // Enable Transmit end interrupt
        SCI1.SCR.BIT.TEIE = 1;

        //_sci_ctrl[0].p_tx_src = 0;

        if (_sci_ctrl[1].callback) {
            _sci_ctrl[1].callback(0, UART_TX_DATA_EMPTY);
        }
    }
}

/***********************************************************************************
Function Name: SCI_Open
Description:   Open SCI.
Parameters:    channel - SCI channel (0 or 1)
               baudrate - Baud rate in bps
Return value:  none
***********************************************************************************/
void SCI_Open(unsigned char channel, unsigned long baudrate) {
    unsigned char dummy;
    int i;

    if (channel > 1) return;

    /* Disable interrupts */
    set_imask_ccr(1);

    /*    Configure port 9 pins as follows -
    P90        - TXD0            - 1 (UART0 TX pin, configured as output low)
    P91        - TXD1            - 1 (UART1 TX pin, configured as output low)
    P92        - RXD0            - 0 (UART0 RX pin, configured as input)
    P93        - RXD1            - 0 (UART1 RX pin, configured as input)
    P94        - SCK0            - 1 (configured as output low)
    P95        - SCK1            - 1 (configured as output low) */

    P9.DR.BYTE = 0x00;
    P9.DDR = 0x33;

    /* Disable transmission/reception */
    /* Clear the bits RIE, TIE,
       TEIE, and MPIE, and bits TE and RE to 0 */
    switch (channel) {
        case 0:
            SCI0.SCR.BYTE = 0x00;
            break;
        case 1:
            SCI1.SCR.BYTE = 0x00;
            ;
            break;
    }
    
    /* Serial Mode Register
        b1:b0 - CKS1:CKS0   - 00 (PHI clock)
        b2    - MP          - 0 (Multiprocessor Mode disabled)
        b3    - STOP        - 0 (1 stop bit)
        b4    - O/E         - 0 (No parity used, not applicable)
        b5    - PE          - 0 (No parity used)
        b6    - CHR         - 0 (Selects 8 bits as the data length)
        b7    - C/A         - 0 (Asynchronous mode)     */
    switch (channel) {
        case 0:
            SCI0.SMR.BYTE = 0x00;
            break;
        case 1:
            SCI1.SMR.BYTE = 0x00;
            break;
    }

    /* Set SCI bit rate generator, BRR value can be calculated as follows -
        BRR value = ((((BRG count source * 2) / 64) / baud rate) - 1)
        Value of n depends on CKS1, CKS0 (transmit/receive mode register)
        Baud rate is based on main crystal / PLL */

    unsigned short brr = (unsigned short)(2 * (((((float)PERIPHERAL_CLK_SPEED * 2u) / 64u) / baudrate) - 1u));
    if (brr % 2) brr++;
    brr = brr / 2;

    switch (channel) {
        case 0:
            SCI0.BRR = (unsigned char)brr;
            break;
        case 1:
            SCI1.BRR = (unsigned char)brr;
            break;
    }

    // Wait for 1 bit interval
    for (i = 0; i < PERIPHERAL_CLK_SPEED/baudrate; i++) {
        nop();    
    }

    /* Serial Control Register (SCR)
        b1:b0 - CKE1:CKE0   - 00 (On-chip baud rate generator
                                  SCK pin functions as I/O port)
        b2    - TEIE        - 0 (Transmit End Interrupt disabled)
        b3    - MPIE        - 0 (Multiprocessor Mode disabled)
        b4    - RE          - 1 (Receive Enabled)
        b5    - TE          - 1 (Transmit Enabled)
        b6    - RIE         - 1 (Receive Interrupt Enabled)
        b7    - TIE         - 0 (Transmit Interrupt disabled) */
    switch (channel) {
        case 0:
            SCI0.SCR.BYTE = 0x70;
            break;
        case 1:
            SCI1.SCR.BYTE = 0x70;
            break;
    }

    /* Enable interrupts */
    set_imask_ccr(0);

    /* dummy read    */
    switch (channel) {
        case 0:
            dummy = (unsigned char)SCI0.RDR;
            break;
        case 1:
            dummy = (unsigned char)SCI1.RDR;
            break;
    }
}

/***********************************************************************************
Function Name : SCI_Close
Description:    Close SCI.
Parameters:     channel - SCI channel (0 or 1)
Return value:   none
***********************************************************************************/
void SCI_Close(unsigned char channel) {
    if (channel > 1) return;

    /* Disable transmission/reception */
    /* Clear the bits RIE, TIE,
       TEIE, and MPIE, and bits TE and RE to 0 */
    switch (channel) {
        case 0:
            SCI0.SCR.BYTE = 0x00;
            break;
        case 1:
            SCI1.SCR.BYTE = 0x00;
            ;
            break;
    }
}

/***********************************************************************************
Function Name : SCI_SetCallback
Description:    Updates the user callback.
Parameters:     channel - SCI channel (0 or 1)
                callback - user callback
Return value:   none
***********************************************************************************/
void SCI_SetCallback(unsigned char channel, callback_t callback) {
    if (channel > 1) return;

    _sci_ctrl[channel].callback = callback;
}

/***********************************************************************************
Function Name : SCI_Read
Description:    Receives user specified number of bytes into destination buffer pointer.
Parameters:     channel - SCI channel (0 or 1)
                p_dest - destination buffer pointer
                bytes - number of bytes to receive
Return value:   none
***********************************************************************************/
void SCI_Read(unsigned char channel, unsigned char* const p_dest, unsigned long const bytes) {
    if (channel > 1) return;

    _sci_ctrl[channel].rx_dest_bytes = bytes;
    _sci_ctrl[channel].p_rx_dest = p_dest;
}

/***********************************************************************************
Function Name : SCI_Write
Description:    Transmits user specified number of bytes from the source buffer pointer.
Parameters:     channel - SCI channel (0 or 1)
                p_src - source buffer pointer
                bytes - number of bytes to transmit
Return value:   none
***********************************************************************************/
void SCI_Write(unsigned char channel, unsigned char* const p_src, unsigned long const bytes) {
    if (channel > 1) return;

    _sci_ctrl[channel].tx_src_bytes = bytes - 1;
    _sci_ctrl[channel].p_tx_src = p_src + 1;

    switch (channel) {
        case 0:
            while (SCI0.SSR.BIT.TDRE != 1) {
                /* Wait till TDRE flag is set */
            }

            set_imask_ccr(1);

            // Enable transmit interrupt
            SCI0.SCR.BIT.TIE = 1;

            /* Output the character on the serial port. */
            SCI0.TDR = *p_src;

            /* Reset the TDRE flag */
            SCI0.SSR.BIT.TDRE = SET_BIT_LOW;

            set_imask_ccr(0);
            break;
        case 1:
            while (SCI1.SSR.BIT.TDRE != 1) {
                /* Wait till TDRE flag is set */
            }

            set_imask_ccr(1);

            // Enable transmit interrupt
            SCI1.SCR.BIT.TIE = 1;

            /* Output the character on the serial port. */
            SCI1.TDR = *p_src;

            /* Reset the TDRE flag */
            SCI1.SSR.BIT.TDRE = SET_BIT_LOW;

            set_imask_ccr(0);
            break;
    }
}
