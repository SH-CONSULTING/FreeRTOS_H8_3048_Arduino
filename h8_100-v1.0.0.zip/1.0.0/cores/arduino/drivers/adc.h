#ifndef __ADC_H
#define __ADC_H

//#include "stdbool.h"

#define bool _Bool
#define true 1
#define false 0

typedef void (*adc_handle_t)();

void ADC_Init(unsigned char mode, unsigned char interrupt, unsigned char channel);
unsigned short ADC_GetValue(unsigned short channel);
unsigned char ADC_Mode();
unsigned char ADC_Interrupt();
unsigned char ADC_Channel();
void ADC_SetCallback(adc_handle_t callback);
void ADC_Start();
void ADC_Stop();
int ADC_PollForConversion(unsigned long long timeout);

void ADC_Start_IT();
void ADC_Stop_IT();

#endif