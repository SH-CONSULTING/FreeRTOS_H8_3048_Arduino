#include "pwm.h"

#include "intrinsic.h"
#include "iodefine.h"

extern volatile itu_ctrl_t _itu_ctrl[5];

/***********************************************************************************
Function Name:  PWM_Open
Description:    Initialize ITU in PWM mode.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_IN_USE: Timer is in use
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_Open(unsigned char channel) {
    itu_config_t config;
    config.mode = TIMER_MODE_PWM;
    config.timer_source = TIMER_SOURCE_DIV_8;
    config.counter_clear = CCLR_CLEAR_ON_GRA_COMPARE_MATCH;
    return ITU_Open(channel, config);
}

/***********************************************************************************
Function Name:  PWM_Close
Description:    Close PWM.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_IN_USE: Timer is in use in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_Close(unsigned char channel) {
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PWM) {
        return TIMER_IN_USE;
    }

    return ITU_Close(channel);
}

/***********************************************************************************
Function Name:  PWM_Start
Description:    Start PWM.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_Start(unsigned char channel) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PWM) {
        return TIMER_NOT_OPEN;
    }
    return ITU_Start(channel);
}

/***********************************************************************************
Function Name:  PWM_Stop
Description:    Stop PWM.
Parameters:     channel: 0-4
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_Stop(unsigned char channel) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PWM) {
        return TIMER_NOT_OPEN;
    }
    return ITU_Stop(channel);
}

/***********************************************************************************
Function Name:  PWM_SetCallback
Description:    Set callback for PWM channel.
Parameters:     channel: 0-4
                callback: callback function
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_SetCallback(unsigned char channel, timer_handle_t callback) {
    if ((channel < ITU_CHANNEL_MAX) && _itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PWM) {
        return TIMER_NOT_OPEN;
    }
    return ITU_SetCallback(channel, callback);
}

/***********************************************************************************
Function Name:  PWM_SetPeriodAndDuty
Description:    Set period and duty cycle in microseconds.
Parameters:     channel: 0-4
                duty_cycle_us: duty cycle in us (duty cycle <= 13107us)
                period_us: period in us (period <= 13107us)
Return value:   TIMER_INVALID_ARGUMENT: Invalid argument
                TIMER_NOT_OPEN: Timer is not open or is in other mode
                TIMER_SUCCESS: Successful
***********************************************************************************/
timer_error_code_t PWM_SetPeriodAndDuty(unsigned char channel, unsigned short duty_cycle_us, unsigned short period_us) {
    timer_error_code_t ret;
    if (channel >= ITU_CHANNEL_MAX) return TIMER_INVALID_ARGUMENT;
    if ((duty_cycle_us > 13107) || (period_us > 13107)) return TIMER_INVALID_ARGUMENT;
    if (_itu_ctrl[channel].open && _itu_ctrl[channel].config.mode != TIMER_MODE_PWM) {
        return TIMER_NOT_OPEN;
    }

    /* Set period */
    ret = ITU_SetGRA(channel, period_us * 5);
    if (ret != TIMER_SUCCESS) return ret;

    /* Set TOFF */
    ret = ITU_SetGRB(channel, duty_cycle_us * 5);
    if (ret != TIMER_SUCCESS) return ret;

    /* Select PWM mode for channel */
    ITU.TMDR.BYTE |= 1 << channel;

    return TIMER_SUCCESS;
}