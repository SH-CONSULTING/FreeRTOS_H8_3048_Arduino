#include "gpio.h"

#include "inthandler.h"
#include "intrinsic.h"
#include "iodefine.h"

static volatile interrupt_handle_t int_handler[6] = {0};

/***********************************************************************************
Function Name: INT_IRQ0
Description:   IRQ0 interrupt handler.
Parameters:    none
Return value:  none
***********************************************************************************/
void INT_IRQ0(void) {
    if (int_handler[0]) int_handler[0]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ0F = 0;
}

/***********************************************************************************
Function Name: INT_IRQ1
Description:   IRQ1 interrupt handler.
Parameters:    none
Return value:  none
***********************************************************************************/
void INT_IRQ1(void) {
    if (int_handler[1]) int_handler[1]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ1F = 0;
}

/***********************************************************************************
Function Name:  INT_IRQ2
Description:    IRQ2 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IRQ2(void) {
    if (int_handler[2]) int_handler[2]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ2F = 0;
}

/***********************************************************************************
Function Name:  INT_IRQ3
Description:    IRQ3 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IRQ3(void) {
    if (int_handler[3]) int_handler[3]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ3F = 0;
}

/***********************************************************************************
Function Name:  INT_IRQ4
Description:    IRQ4 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IRQ4(void) {
    if (int_handler[4]) int_handler[4]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ4F = 0;
}

/***********************************************************************************
Function Name:  INT_IRQ5
Description:    IRQ5 interrupt handler.
Parameters:     none
Return value:   none
***********************************************************************************/
void INT_IRQ5(void) {
    if (int_handler[5]) int_handler[5]();
    /* Clear interrupt flag */
    INTC.ISR.BIT.IRQ5F = 0;
}

/***********************************************************************************
Function Name:  IOPORT_PortDirectionSet
Description:    Set port direction.
Parameters:     port - port
                direction - for 8 pins (0: input, 1: output)
Return value:   none
***********************************************************************************/
void IOPORT_PortDirectionSet(io_port_t port, unsigned char direction) {
    switch (port) {
        case IO_PORT_01:
            P1.DDR = direction;
            break;
        case IO_PORT_02:
            P2.DDR = direction;
            break;
        case IO_PORT_03:
            P3.DDR = direction;
            break;
        case IO_PORT_04:
            P4.DDR = direction;
            break;
        case IO_PORT_05:
            P5.DDR = direction;
            break;
        case IO_PORT_06:
            P6.DDR = direction;
            break;
        case IO_PORT_07:
            /* Port 7 is input only */
            break;
        case IO_PORT_08:
            P8.DDR = direction;
            break;
        case IO_PORT_09:
            P9.DDR = direction;
            break;
        case IO_PORT_0A:
            PA.DDR = direction;
            break;
        case IO_PORT_0B:
            PB.DDR = direction;
            break;
    }
}

/***********************************************************************************
Function Name:  IOPORT_PinRead
Description:    Read a pin
Parameters:     pin - pin to read
                value - output value
Return value:   none
***********************************************************************************/
void IOPORT_PinRead(io_port_pin_t pin, io_level_t *value) {
    unsigned char byte;
    io_port_t port;
    port = pin / 8;
    unsigned char bit = pin % 8;
    IOPORT_PortRead(port, &byte);
    *value = (byte >> bit) & 0x01;
}

/***********************************************************************************
Function Name:  IOPORT_PinWrite
Description:    Write value to a pin
Parameters:     pin - pin to write
                value - value to write
Return value:   none
***********************************************************************************/
void IOPORT_PinWrite(io_port_pin_t pin, io_level_t value) {
    unsigned char byte;
    io_port_t port;
    port = pin / 8;
    unsigned char bit = pin % 8;
    IOPORT_PortRead(port, &byte);
    byte = (byte & ~(1 << bit)) | (value << bit);
    IOPORT_PortWrite(port, byte);
}

/***********************************************************************************
Function Name:  IOPORT_PortRead
Description:    Read a port
Parameters:     port - port to read
                value - output value
Return value:   none
***********************************************************************************/
void IOPORT_PortRead(io_port_t port, unsigned char *value) {
    switch (port) {
        case IO_PORT_01:
            *value = P1.DR.BYTE;
            break;
        case IO_PORT_02:
            *value = P2.DR.BYTE;
            break;
        case IO_PORT_03:
            *value = P3.DR.BYTE;
            break;
        case IO_PORT_04:
            *value = P4.DR.BYTE;
            break;
        case IO_PORT_05:
            *value = P5.DR.BYTE;
            break;
        case IO_PORT_06:
            *value = P6.DR.BYTE;
            break;
        case IO_PORT_07:
            *value = P7.DR.BYTE;
            break;
        case IO_PORT_08:
            *value = P8.DR.BYTE;
            break;
        case IO_PORT_09:
            *value = P9.DR.BYTE;
            break;
        case IO_PORT_0A:
            *value = PA.DR.BYTE;
            break;
        case IO_PORT_0B:
            *value = PB.DR.BYTE;
            break;
    }
}

/***********************************************************************************
Function Name:  IOPORT_PortWrite
Description:    Write value to a port
Parameters:     port - port to write
                value - value to write
Return value:   none
***********************************************************************************/
void IOPORT_PortWrite(io_port_t port, unsigned char value) {
    switch (port) {
        case IO_PORT_01:
            P1.DR.BYTE = value;
            break;
        case IO_PORT_02:
            P2.DR.BYTE = value;
            break;
        case IO_PORT_03:
            P3.DR.BYTE = value;
            break;
        case IO_PORT_04:
            P4.DR.BYTE = value;
            break;
        case IO_PORT_05:
            P5.DR.BYTE = value;
            break;
        case IO_PORT_06:
            P6.DR.BYTE = value;
            break;
        case IO_PORT_07:
            /* Port 7 is input only */
            break;
        case IO_PORT_08:
            P8.DR.BYTE = value;
            break;
        case IO_PORT_09:
            P9.DR.BYTE = value;
            break;
        case IO_PORT_0A:
            PA.DR.BYTE = value;
            break;
        case IO_PORT_0B:
            PB.DR.BYTE = value;
            break;
    }
}

/***********************************************************************************
Function Name:  IOPORT_SetCallback
Description:    Set user callback
Parameters:     irq_no - irq number (0-5)
                callback - user callback
                mode - interrupt mode
Return value:   none
***********************************************************************************/
void IOPORT_SetCallback(unsigned char irq_no, interrupt_handle_t callback, interrupt_mode_t mode) {
    set_imask_ccr(1);

    if (callback) {
        INTC.ISCR.BYTE = (INTC.ISCR.BYTE & ~(1 << irq_no)) | (mode << irq_no);
        INTC.IER.BYTE |= 1 << irq_no;
        INTC.ISR.BYTE &= ~(1 << irq_no);
        int_handler[irq_no] = callback;
    } else {
        INTC.IER.BYTE &= ~(1 << irq_no);
        INTC.ISR.BYTE &= ~(1 << irq_no);
        int_handler[irq_no] = 0;
    }

    set_imask_ccr(0);
}