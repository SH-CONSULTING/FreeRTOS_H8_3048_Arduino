#ifndef __DAC_H
#define __DAC_H

typedef enum {
    DAC_CHANNEL_0,
    DAC_CHANNEL_1,
    DAC_CHANNEL_ALL
} dac_channel;

void DAC_Start(dac_channel channel);
void DAC_Stop(dac_channel channel);
void DAC_SetValue(dac_channel channel, unsigned char value);
void DAC_Standby(unsigned char value);

#endif